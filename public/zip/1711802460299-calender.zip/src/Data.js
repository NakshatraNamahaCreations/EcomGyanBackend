export const jsonData = [
  {
    title: "Lois Lane",
    date: "2023-06-01",
    city: "Chennai",
  },
  {
    title: "Clark Kent",
    date: "2023-06-01",
    city: "Mumbai",
  },
  {
    title: "Ralph",
    date: "2023-06-02",
    city: "Bangalore",
  },
  {
    title: "Alice Kramden",
    date: "2023-06-04",
    city: "Delhi",
  },
  {
    title: "Holly Golightly",
    date: "2023-06-05",
    city: "Noida",
  },
  {
    title: "Liza Doolittle",
    date: "2023-06-07",
    city: "Kolkata",
  },
  {
    title: "Henry Higgins",
    date: "2023-06-09",
    city: "Chennai",
  },
  {
    title: "Joseph Arimathea",
    date: "2023-06-09",
    city: "Mysore",
  },
  {
    title: "Mary Magdalene",
    date: "2023-06-08",
    city: "Hydrabad",
  },
];
