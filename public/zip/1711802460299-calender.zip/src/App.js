import { Route, Routes } from "react-router-dom";
import "./App.css";
import EventTable from "./EventTable";
import EventCalendar from "./EventCalendar";

function App() {
  return (
    <div className="App">
      <Routes>
        <Route exact path="/" element={<EventCalendar />} />
        <Route path="/table/:date" element={<EventTable />} />
      </Routes>
    </div>
  );
}

export default App;
