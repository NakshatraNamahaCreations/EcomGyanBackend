// TablePage.js
import React from "react";
import { useParams, Link } from "react-router-dom";
import { jsonData } from "./Data";
import { Table } from "react-bootstrap";

const EventTable = () => {
  const { date } = useParams();

  const filteredEvents = jsonData.filter((event) => event.date === date);

  return (
    <div style={{ margin: "1%" }}>
      {/* <h1>Table Page</h1> */}
      <Link to="/">
        <div style={{ textAlign: "left" }}>Go Back</div>
      </Link>
      <div
        style={{
          backgroundColor: "rgb(169, 4, 46)",
          color: "white",
          padding: "8px",
          fontSize: "19px",
          marginBottom: "15px",
          margin: "2%",
        }}
      >
        Events on {date}
      </div>
      <Table
        striped
        bordered
        hover
        size="sm"
        style={{ width: "50%", marginLeft: "15%", border: "2px solid" }}
      >
        <thead>
          <tr>
            <th>Name</th>
            <th>City</th>
            <th>Nxt Foll</th>
          </tr>
        </thead>
        <tbody>
          {filteredEvents?.map((event, index) => (
            <tr key={index}>
              <td>{event.title}</td>
              <td>{event.city}</td>
              <td>{event.date}</td>
            </tr>
          ))}
        </tbody>
      </Table>
      {/* <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>City</th>
            <th>Nxt Foll</th>
          </tr>
        </thead>
        <tbody>
          {filteredEvents?.map((event, index) => (
            <tr key={index}>
              <td>{event.title}</td>
              <td>{event.city}</td>
              <td>{event.date}</td>
            </tr>
          ))}
        </tbody>
      </table> */}
    </div>
  );
};

export default EventTable;
