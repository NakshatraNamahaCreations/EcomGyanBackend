import { Calendar, momentLocalizer } from "react-big-calendar";
import moment from "moment";
import "react-big-calendar/lib/css/react-big-calendar.css";
import { jsonData } from "./Data";
import { useNavigate } from "react-router-dom";

function EventCalendar() {
  const localizer = momentLocalizer(moment);
  const navigate = useNavigate();

  const currentDate = moment().format("dddd, MM/DD/YYYY");

  const eventCounts = jsonData.reduce((counts, item) => {
    const date = item.date;
    counts[date] = (counts[date] || 0) + 1;
    return counts;
  }, {});

  const myEventsList = Object.keys(eventCounts).map((date) => ({
    title: `${eventCounts[date]} Followup`,
    start: new Date(date),
    end: new Date(date),
    count: eventCounts[date],
  }));

  const handleSelectEvent = (event) => {
    const selectedDate = moment(event.start).format("YYYY-MM-DD");
    navigate(`/table/${selectedDate}`);
  };
  return (
    <div className="App">
      <div style={{ width: "94%", margin: "3%" }}>
        <div
          style={{
            backgroundColor: "rgb(169, 4, 46)",
            color: "white",
            padding: "8px",
            fontSize: "19px",
            marginBottom: "15px",
          }}
        >
          {" "}
          {currentDate}
        </div>
        <Calendar
          localizer={localizer}
          events={myEventsList}
          startAccessor="start"
          endAccessor="end"
          selectable
          onSelectEvent={handleSelectEvent}
          style={{ height: 500 }}
        />
      </div>
    </div>
  );
}

export default EventCalendar;
