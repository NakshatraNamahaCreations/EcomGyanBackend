const mongoose = require("mongoose");

const myCourseSchema = new mongoose.Schema(
  {
    // Add Course
    courseName: String,
    courseDescription: String,
    freeMaterialDocs: String,
    materialDocsId: String,
    freeMaterialVideo: String,
    materialVideoId: String,
    thumbnailImage: String,
    durationType: String,
    validity: String,
    validityPeriod: String,
    price: Number,
    discount: Number,
    effectivePrice: Number,
    // Add Modules
    // modules: [
    //   {
    //     moduleTitle: String,
    //     description: String,
    //     videoLinks: [String],
    //     documentFiles: [String]
    //   }
    // ],
    // moduleName: String,
    // moduleDescription: String,
    // courseDescription: String,
    // courseName: String,
    // courseDescription: String,
    // courseName: String,
    // courseDescription: String,
    // courseName: String,
    // courseDescription: String,
  },
  {
    timestamps: true,
  }
);

const myCourse = mongoose.model("MyCourse", myCourseSchema);
module.exports = myCourse;
